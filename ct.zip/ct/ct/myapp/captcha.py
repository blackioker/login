from selenium import webdriver
import time
from PIL import Image
from selenium.webdriver.common.action_chains import ActionChains
import os
import requests
import numpy



def click_button(b, id, dest_text, j):
    txt = ''
    for i in range(0, 5):
        try:
            txt = b.find_element_by_id(id).text
            if txt == dest_text:
                b.find_element_by_id(id).click()
                return 0
            else:
                return 1

        except:
            time.sleep(1)
            continue

    return -1



def find_button(b, id, dest_text):
    txt = ''
    try:
        txt = b.find_element_by_id(id).text
        if txt == dest_text:
            return 0
    except:
        return -1

    return -1



def click_refresh(b):
    try:
        b.find_element_by_xpath("//*[@id='loginForm']/div/ul[2]/li[4]/div/div/div[1]").click()
    except:
        print("click_refresh:exception!!!!")



def init_browser(b):
    b.maximize_window()



def visit_login_page(b):
    url = 'https://kyfw.12306.cn/otn/index/init'
    b.get(url)
    if find_button(b, u"login_user", u"登录") != 0:
        click_button(b, u"regist_out", u"退出", 0)
        time.sleep(5)

    if click_button(b, u"login_user", u"登录", 0) != 0:
        return -1

    time.sleep(10)
    return 0


# 截取一张验证码图片，保存为aa.png
def get_a_verify_pic(b):
    imgelement = b.find_element_by_xpath("//*[@id='loginForm']/div/ul[2]/li[4]/div/div/div[3]")
    location = imgelement.location
    size = imgelement.size
    rangle = (int(location['x']), int(location['y']), int(location['x'] + size['width']),
              int(location['y'] + size['height']))
    b.save_screenshot('pic.png')
    i = Image.open("pic.png")
    pic_name = 'verify_code' + ".jpg"
    frame4 = i.crop(rangle)
    frame4.save(pic_name)
    return pic_name


def ana_pic(b, pic_name):
    body_list = []
    url = '''http://littlebigluo.qicp.net:47720/'''
    files = {'file': (pic_name, open(pic_name, 'rb'), 'img/png')}
    res = requests.post(url, files=files)

    if res.status_code == 200:
        try:
            if u"文字应该" in res.text:
                body_str_1 = res.text.split(u'''<B>''')
                body_str = body_str_1[2].split(u'<')[0].split()
                for index in body_str:
                    body_list.append(int(index))
                return 0, numpy.array(body_list)

        except:
            print("ana pic failed!!!!")
            return -1, None

    return -1, None



def click_one_pic(b, i):
    try:
        imgelement = b.find_element_by_xpath("//*[@id='loginForm']/div/ul[2]/li[4]/div/div/div[3]")
        if i <= 4:
            ActionChains(b).move_to_element_with_offset(imgelement, 40 + 72 * (i - 1), 73).click().perform()
        else:
            i -= 4
            ActionChains(b).move_to_element_with_offset(imgelement, 40 + 72 * (i - 1), 145).click().perform()
    except:
        print("Wa -- click one pic except!!!")


def click_pic(b, body_list):
    for i in range(len(body_list)):
        click_one_pic(b, body_list[i])
        time.sleep(1)



def login(b):
    pic_name = None
    try:

        pic_name = get_a_verify_pic(b)
        ret_val, body_list = ana_pic(b, pic_name)

        username = b.find_element_by_id('J-userName')
        username.clear()
        username.send_keys('18867741831')
        password = b.find_element_by_id('J-password')
        password.clear()
        password.send_keys('asd134679')
        time.sleep(2)

        if ret_val != 0:
            print("login -- no verified pic!!! !!")
            os.remove(pic_name)
            return -1

        if len(body_list) == 0:
            click_refresh(b)
            print("login : what??? body list is null!!!")
            os.remove(pic_name)
            return 1

        click_pic(b, body_list)
        time.sleep(1)
        if click_button(b, u"loginSub", u"登录", 0) != 0:
            print("login : what??? click button exception!!!")
            return -1
    except:
        if None != pic_name:
            os.remove(pic_name)
        print("login:exception!!")
        return -1

    time.sleep(5)
    ret_val = find_button(b, u"error_msgmypasscode1", u"请点击正确的验证码")
    if ret_val == 0:
        print("login--Verified code error!!!")
        return 1

    os.remove(pic_name)
    print("login--successfully!!!")
    return 0

def try_login(b):
    for k in range(0, 5):
        rt_val = login(b)
        if rt_val < 0:
            print("verify got exception!!")
            time.sleep(10)
            continue
        elif rt_val == 1:
            print("verify - code error!!")
            time.sleep(5)
            continue  # login again
        else:
            print("login successfully!!!")
            return 0

    return -1


def mylogin():

    b = webdriver.Chrome()
    init_browser(b)
    visit_login_page(b)

    ret_val = try_login(b)
    if ret_val < 0:
        print("main -- try_login failed!!!")
    else:
        print("main -- try_login successfully!!!")

    print("Good job！bigluo！！")
    return "Good job！bigluo！！"
